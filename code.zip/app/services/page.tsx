import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Services - RS Constructions",
  description: "Découvrez nos services de rénovation et construction au Maroc",
}

export default function ServicesPage() {
  const services = [
    {
      title: "Rénovation d'Appartements",
      description: "Transformation complète de vos appartements avec un suivi professionnel",
      details: [
        "Rénovation intérieure complète",
        "Plomberie et électricité",
        "Peinture et revêtements",
        "Installation de cuisines et salles de bains",
      ],
    },
    {
      title: "Rénovation de Villas",
      description: "Expertise dans la rénovation de villas résidentielles de haut standing",
      details: [
        "Rénovation structurelle",
        "Extension et agrandissement",
        "Aménagement de jardins",
        "Domotique et installations modernes",
      ],
    },
    {
      title: "Construction d'Immeubles",
      description: "Construction de projets immobiliers résidentiels et commerciaux",
      details: [
        "Études et permis de construire",
        "Supervision des travaux",
        "Contrôle de qualité rigoureux",
        "Respect des normes marocaines",
      ],
    },
    {
      title: "Maçonnerie",
      description: "Travaux de maçonnerie et gros œuvres pour tous vos projets",
      details: [
        "Fondations et structures",
        "Création d'ouvertures",
        "Revêtements de façades",
        "Carrelage et finitions",
      ],
    },
    {
      title: "Menuiserie",
      description: "Créations sur mesure en menuiserie bois et aluminium",
      details: ["Portes et fenêtres", "Escaliers et rampes", "Aménagements intérieurs", "Menuiserie métallique"],
    },
    {
      title: "Électricité & Plomberie",
      description: "Installations conformes aux normes internationales",
      details: [
        "Installation électrique complète",
        "Plomberie sanitaire",
        "Chauffage et climatisation",
        "Système de sécurité incendie",
      ],
    },
  ]

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground py-12 md:py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4 text-balance">Nos Services</h1>
            <p className="text-lg md:text-xl opacity-90 text-balance">
              Solutions complètes en construction et rénovation pour tous vos projets
            </p>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-12 md:py-20 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((service, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                    <CardDescription>{service.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {service.details.map((detail, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                          <span className="text-sm">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-20 bg-muted/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl md:text-4xl font-bold mb-4">Besoin d'un service spécifique ?</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Contactez nos experts pour discuter de votre projet et recevoir un devis personnalisé
            </p>
            <Link href="/#contact">
              <Button size="lg">Demander un devis</Button>
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
