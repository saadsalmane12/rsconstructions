import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Award, Users, Target, Zap } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "À Propos - RS Constructions",
  description: "En savoir plus sur RS Constructions et notre expertise",
}

export default function AboutPage() {
  const values = [
    {
      icon: Target,
      title: "Notre Mission",
      description: "Fournir des solutions de construction et rénovation de qualité exceptionnelle",
    },
    {
      icon: Award,
      title: "Excellence",
      description: "Chaque projet est réalisé avec les plus hauts standards de qualité",
    },
    {
      icon: Users,
      title: "Équipe Expérimentée",
      description: "Une équipe de professionnels qualifiés et expérimentés",
    },
    {
      icon: Zap,
      title: "Innovation",
      description: "Utilisation des techniques et matériaux les plus modernes",
    },
  ]

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground py-12 md:py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4 text-balance">À Propos de RS Constructions</h1>
            <p className="text-lg md:text-xl opacity-90 text-balance">
              Plus de 15 ans d'expertise au service de vos projets
            </p>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-12 md:py-20 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold mb-6">Notre Histoire</h2>
              <div className="space-y-4 text-lg text-muted-foreground">
                <p>
                  RS Constructions a été fondée avec la vision de transformer les espaces et les vies à travers une
                  construction et une rénovation de qualité exceptionnelle. Depuis nos débuts, nous avons travaillé sans
                  relâche pour établir une réputation de fiabilité et d'excellence.
                </p>
                <p>
                  Basée à Casablanca, notre entreprise s'est développée pour devenir l'une des plus réputées au Maroc.
                  Nous avons réalisé plus de 500 projets, allant des rénovations résidentielles aux constructions
                  d'immeubles commerciaux de grande envergure.
                </p>
                <p>
                  Notre succès repose sur trois pilliers fondamentaux : une équipe de professionnels expérimentés, une
                  utilisation de matériaux de qualité supérieure, et une écoute attentive des besoins de nos clients.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-12 md:py-20 bg-muted/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold mb-12 text-center">Nos Valeurs</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => {
                const Icon = value.icon
                return (
                  <Card key={index}>
                    <CardHeader>
                      <Icon className="h-8 w-8 text-accent mb-2" />
                      <CardTitle>{value.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">{value.description}</p>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-12 md:py-20 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold mb-12 text-center">Pourquoi Nous Choisir ?</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">Expertise Reconnue</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>✓ Plus de 15 ans d'expérience</li>
                  <li>✓ 500+ projets réalisés avec succès</li>
                  <li>✓ Équipe de plus de 50 professionnels qualifiés</li>
                  <li>✓ Certifications et agréments à jour</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">Engagement Qualité</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>✓ Utilisation de matériaux premium</li>
                  <li>✓ Respect strict des normes marocaines</li>
                  <li>✓ Garanties complètes sur tous les travaux</li>
                  <li>✓ Suivi rigoureux du chantier du début à la fin</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-20 bg-muted/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl md:text-4xl font-bold mb-4">Prêt à Commencer Votre Projet ?</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Contactez-nous aujourd'hui pour une consultation gratuite
            </p>
            <Link href="/#contact">
              <Button size="lg">Nous Contacter</Button>
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
