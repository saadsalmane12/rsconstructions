import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

export const metadata = {
  title: "Demander un Devis - RS Constructions",
  description: "Demandez un devis gratuit pour votre projet de construction ou rénovation",
}

export default function QuotePage() {
  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground py-12 md:py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4 text-balance">Demander un Devis</h1>
            <p className="text-lg md:text-xl opacity-90 text-balance">
              Obtenez un devis personnalisé gratuitement en 24-48 heures
            </p>
          </div>
        </section>

        {/* Form Section */}
        <section className="py-12 md:py-20 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle>Formulaire de Devis</CardTitle>
                </CardHeader>
                <CardContent>
                  <form className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Nom Complet *</Label>
                        <Input id="name" placeholder="Votre nom" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Téléphone *</Label>
                        <Input id="phone" type="tel" placeholder="+212 5 XX XX XX XX" required />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" placeholder="votre.email@example.com" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="city">Ville *</Label>
                        <Select>
                          <SelectTrigger id="city">
                            <SelectValue placeholder="Sélectionnez une ville" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="casablanca">Casablanca</SelectItem>
                            <SelectItem value="rabat">Rabat</SelectItem>
                            <SelectItem value="fes">Fès</SelectItem>
                            <SelectItem value="marrakech">Marrakech</SelectItem>
                            <SelectItem value="agadir">Agadir</SelectItem>
                            <SelectItem value="tangier">Tanger</SelectItem>
                            <SelectItem value="meknes">Meknès</SelectItem>
                            <SelectItem value="other">Autre</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="service">Type de Service *</Label>
                      <Select>
                        <SelectTrigger id="service">
                          <SelectValue placeholder="Sélectionnez un service" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="apartment">Rénovation d'Appartement</SelectItem>
                          <SelectItem value="villa">Rénovation de Villa</SelectItem>
                          <SelectItem value="building">Construction d'Immeuble</SelectItem>
                          <SelectItem value="masonry">Maçonnerie</SelectItem>
                          <SelectItem value="carpentry">Menuiserie</SelectItem>
                          <SelectItem value="electrical">Électricité & Plomberie</SelectItem>
                          <SelectItem value="other">Autre</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="area">Surface Approximative (m²)</Label>
                      <Input id="area" type="number" placeholder="Ex: 150" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="budget">Budget Approximatif (MAD)</Label>
                      <Select>
                        <SelectTrigger id="budget">
                          <SelectValue placeholder="Sélectionnez un budget" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0-50k">0 - 50,000 DH</SelectItem>
                          <SelectItem value="50k-100k">50,000 - 100,000 DH</SelectItem>
                          <SelectItem value="100k-250k">100,000 - 250,000 DH</SelectItem>
                          <SelectItem value="250k-500k">250,000 - 500,000 DH</SelectItem>
                          <SelectItem value="500k">500,000+ DH</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="timeline">Délai Souhaité</Label>
                      <Select>
                        <SelectTrigger id="timeline">
                          <SelectValue placeholder="Sélectionnez un délai" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="urgent">Urgent (moins d'1 mois)</SelectItem>
                          <SelectItem value="soon">Bientôt (1-3 mois)</SelectItem>
                          <SelectItem value="flexible">Flexible (3-6 mois)</SelectItem>
                          <SelectItem value="no-hurry">Pas d'urgence (6+ mois)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="details">Détails du Projet *</Label>
                      <Textarea
                        id="details"
                        placeholder="Décrivez votre projet en détail..."
                        className="min-h-32"
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full">
                      Envoyer ma Demande
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Info Section */}
        <section className="py-12 md:py-20 bg-muted/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Comment Cela Fonctionne ?</h2>
            <div className="grid md:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="text-center">
                  <div className="bg-accent text-accent-foreground rounded-full h-10 w-10 flex items-center justify-center font-bold mx-auto mb-4">
                    1
                  </div>
                  <CardTitle className="text-lg">Envoyez Votre Devis</CardTitle>
                </CardHeader>
                <CardContent className="text-center text-sm text-muted-foreground">
                  Remplissez le formulaire avec les détails de votre projet
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <div className="bg-accent text-accent-foreground rounded-full h-10 w-10 flex items-center justify-center font-bold mx-auto mb-4">
                    2
                  </div>
                  <CardTitle className="text-lg">Analyse</CardTitle>
                </CardHeader>
                <CardContent className="text-center text-sm text-muted-foreground">
                  Notre équipe analyse votre projet en détail
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <div className="bg-accent text-accent-foreground rounded-full h-10 w-10 flex items-center justify-center font-bold mx-auto mb-4">
                    3
                  </div>
                  <CardTitle className="text-lg">Consultation</CardTitle>
                </CardHeader>
                <CardContent className="text-center text-sm text-muted-foreground">
                  Nous vous contactons pour discuter de votre projet
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <div className="bg-accent text-accent-foreground rounded-full h-10 w-10 flex items-center justify-center font-bold mx-auto mb-4">
                    4
                  </div>
                  <CardTitle className="text-lg">Devis Personnalisé</CardTitle>
                </CardHeader>
                <CardContent className="text-center text-sm text-muted-foreground">
                  Recevez un devis détaillé et transparent
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
