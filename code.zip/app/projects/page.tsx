import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"

export const metadata = {
  title: "Projets - RS Constructions",
  description: "Découvrez nos réalisations en construction et rénovation",
}

export default function ProjectsPage() {
  const projects = [
    {
      slug: "villa-riad-casablanca",
      title: "Rénovation Villa Riad Casablanca",
      category: "Rénovation Villa",
      image: "/luxury-villa-renovation-casablanca.jpg",
      location: "Casablanca",
    },
    {
      slug: "immeuble-residenciel-marrakech",
      title: "Construction Immeuble Résidentiel",
      category: "Construction",
      image: "/modern-residential-building-marrakech.jpg",
      location: "Marrakech",
    },
    {
      slug: "appartement-derb-ghalef-fes",
      title: "Rénovation Appartement Derb Ghalef",
      category: "Rénovation Appartement",
      image: "/apartment-renovation-fes.jpg",
      location: "Fès",
    },
    {
      slug: "villa-moderne-piscine-rabat",
      title: "Villa Moderne avec Piscine",
      category: "Rénovation Villa",
      image: "/modern-villa-with-pool-rabat.jpg",
      location: "Rabat",
    },
    {
      slug: "centre-commercial-casablanca",
      title: "Centre Commercial Rénové",
      category: "Construction Commerciale",
      image: "/commercial-center-renovation.jpg",
      location: "Casablanca",
    },
    {
      slug: "residence-luxe-agadir",
      title: "Résidence de Luxe Agadir",
      category: "Construction",
      image: "/luxury-residential-complex-agadir.jpg",
      location: "Agadir",
    },
  ]

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground py-12 md:py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4 text-balance">Nos Projets</h1>
            <p className="text-lg md:text-xl opacity-90 text-balance">
              Découvrez nos réalisations les plus prestigieuses à travers le Maroc
            </p>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="py-12 md:py-20 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project) => (
                <Link key={project.slug} href={`/projects/${project.slug}`}>
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group h-full">
                    <div className="relative h-64 overflow-hidden">
                      <Image
                        src={project.image || "/placeholder.svg"}
                        alt={project.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <CardContent className="pt-4">
                      <p className="text-sm text-accent font-semibold mb-2">{project.category}</p>
                      <h3 className="font-bold text-lg mb-2">{project.title}</h3>
                      <p className="text-sm text-muted-foreground">{project.location}</p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 md:py-20 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-4xl md:text-5xl font-bold mb-2">500+</div>
                <p className="text-lg opacity-90">Projets réalisés</p>
              </div>
              <div>
                <div className="text-4xl md:text-5xl font-bold mb-2">15+</div>
                <p className="text-lg opacity-90">Ans d'expérience</p>
              </div>
              <div>
                <div className="text-4xl md:text-5xl font-bold mb-2">100%</div>
                <p className="text-lg opacity-90">Clients satisfaits</p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
