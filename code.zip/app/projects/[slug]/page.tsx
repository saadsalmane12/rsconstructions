import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, Calendar, MapPin, Users, CheckCircle } from "lucide-react"

const projects = [
  {
    slug: "villa-riad-casablanca",
    title: "Rénovation Villa Riad Casablanca",
    category: "Rénovation Villa",
    image: "/luxury-villa-renovation-casablanca.jpg",
    location: "Casablanca",
    date: "2023",
    duration: "6 mois",
    team: "12 ouvriers",
    client: "Famille Bennani",
    description:
      "Rénovation complète d'une magnifique villa Riad à Casablanca. Ce projet a transformé une maison traditionnelle en un espace moderne tout en préservant son charme authentique.",
    details: [
      "Restructuration complète de l'intérieur",
      "Installation de systèmes modernes (électricité, plomberie)",
      "Création d'une piscine contemporaine",
      "Rénovation des toitures et façades",
      "Aménagement paysager du jardin",
      "Installation de climatisation central",
    ],
    images: [
      "/luxury-villa-renovation-casablanca.jpg",
      "/luxury-villa-renovation-casablanca.jpg",
      "/luxury-villa-renovation-casablanca.jpg",
    ],
    budget: "450 000 DH",
    status: "Achevé",
    highlights: [
      { title: "Surface", value: "350 m²" },
      { title: "Pièces", value: "7 chambres" },
      { title: "Innovation", value: "Domotique complète" },
    ],
  },
  {
    slug: "immeuble-residenciel-marrakech",
    title: "Construction Immeuble Résidentiel",
    category: "Construction",
    image: "/modern-residential-building-marrakech.jpg",
    location: "Marrakech",
    date: "2022-2023",
    duration: "18 mois",
    team: "25 ouvriers",
    client: "Groupe Immobilier Al Amal",
    description:
      "Construction d'un immeuble résidentiel moderne de 8 étages à Marrakech. Ce projet a combiné design contemporain et conformité aux normes de construction marocaines.",
    details: [
      "Construction structure béton armé",
      "24 appartements (du T2 au T4)",
      "Parking souterrain 40 places",
      "Espaces communs et piscine",
      "Norme parasismique appliquée",
      "Conformité énergétique et thermique",
    ],
    images: [
      "/modern-residential-building-marrakech.jpg",
      "/modern-residential-building-marrakech.jpg",
      "/modern-residential-building-marrakech.jpg",
    ],
    budget: "2 500 000 DH",
    status: "Achevé",
    highlights: [
      { title: "Étages", value: "8" },
      { title: "Unités", value: "24 appartements" },
      { title: "Conformité", value: "Normes marocaines" },
    ],
  },
  {
    slug: "appartement-derb-ghalef-fes",
    title: "Rénovation Appartement Derb Ghalef",
    category: "Rénovation Appartement",
    image: "/apartment-renovation-fes.jpg",
    location: "Fès",
    date: "2023",
    duration: "4 mois",
    team: "6 ouvriers",
    client: "Mme Fatima Alaoui",
    description:
      "Rénovation moderne d'un appartement traditionnel dans la médina de Fès. Ce projet montre comment moderniser un espace ancien tout en respectant le patrimoine local.",
    details: [
      "Reprise de la structure",
      "Installation électrique et plomberie neuve",
      "Peinture et finitions modernes",
      "Aménagement cuisine équipée",
      "Salle de bain design",
      "Revêtements de qualité",
    ],
    images: ["/apartment-renovation-fes.jpg", "/apartment-renovation-fes.jpg", "/apartment-renovation-fes.jpg"],
    budget: "120 000 DH",
    status: "Achevé",
    highlights: [
      { title: "Surface", value: "85 m²" },
      { title: "Pièces", value: "3 chambres" },
      { title: "Qualité", value: "Premium" },
    ],
  },
  {
    slug: "villa-moderne-piscine-rabat",
    title: "Villa Moderne avec Piscine",
    category: "Rénovation Villa",
    image: "/modern-villa-with-pool-rabat.jpg",
    location: "Rabat",
    date: "2022",
    duration: "8 mois",
    team: "14 ouvriers",
    client: "Entreprise Technologique",
    description:
      "Construction d'une villa moderne luxueuse avec piscine à débordement. Ce projet exemplifie notre expertise dans la création de résidences haut de gamme.",
    details: [
      "Architecture contemporaine épurée",
      "Piscine avec débordement infini",
      "Terrasse panoramique",
      "Home cinéma et salle de sport",
      "Jardin paysagé méditerranéen",
      "Efficacité énergétique maximale",
    ],
    images: [
      "/modern-villa-with-pool-rabat.jpg",
      "/modern-villa-with-pool-rabat.jpg",
      "/modern-villa-with-pool-rabat.jpg",
    ],
    budget: "1 800 000 DH",
    status: "Achevé",
    highlights: [
      { title: "Surface", value: "450 m²" },
      { title: "Étages", value: "2" },
      { title: "Luxe", value: "Premium 5 étoiles" },
    ],
  },
  {
    slug: "centre-commercial-casablanca",
    title: "Centre Commercial Rénové",
    category: "Construction Commerciale",
    image: "/commercial-center-renovation.jpg",
    location: "Casablanca",
    date: "2021-2022",
    duration: "14 mois",
    team: "20 ouvriers",
    client: "Groupe Retail Al Mansour",
    description:
      "Rénovation complète d'un centre commercial de 15 000 m² à Casablanca. Ce projet majeur a modernisé les installations tout en maintenant l'activité commerciale.",
    details: [
      "Restructuration des espaces de vente",
      "Rénovation des façades",
      "Systèmes modernes de sécurité",
      "Escalators et ascenseurs neufs",
      "Éclairage LED économique",
      "Parking rénové et sécurisé",
    ],
    images: [
      "/commercial-center-renovation.jpg",
      "/commercial-center-renovation.jpg",
      "/commercial-center-renovation.jpg",
    ],
    budget: "3 500 000 DH",
    status: "Achevé",
    highlights: [
      { title: "Surface", value: "15 000 m²" },
      { title: "Étages", value: "4" },
      { title: "Commerces", value: "80+ boutiques" },
    ],
  },
  {
    slug: "residence-luxe-agadir",
    title: "Résidence de Luxe Agadir",
    category: "Construction",
    image: "/luxury-residential-complex-agadir.jpg",
    location: "Agadir",
    date: "2023-2024",
    duration: "12 mois",
    team: "18 ouvriers",
    client: "Développeur Immobilier Elite",
    description:
      "Construction d'une résidence de luxe composée de 12 villas avec accès à la plage. Ce projet de prestige combine luxe, confort et respect de l'environnement côtier.",
    details: [
      "12 villas de 500 m² chacune",
      "Accès direct à la plage privée",
      "Club house avec piscine",
      "Sécurité 24/7 et contrôle d'accès",
      "Aménagement paysager premium",
      "Marina privée intégrée",
    ],
    images: [
      "/luxury-residential-complex-agadir.jpg",
      "/luxury-residential-complex-agadir.jpg",
      "/luxury-residential-complex-agadir.jpg",
    ],
    budget: "8 500 000 DH",
    status: "En cours",
    highlights: [
      { title: "Villas", value: "12" },
      { title: "Surface totale", value: "6 000 m²" },
      { title: "Environnement", value: "Bord de mer" },
    ],
  },
]

export function generateStaticParams() {
  return projects.map((project) => ({
    slug: project.slug,
  }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const project = projects.find((p) => p.slug === slug)

  return {
    title: `${project?.title} - RS Constructions`,
    description: project?.description,
  }
}

export default async function ProjectDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const project = projects.find((p) => p.slug === slug)

  if (!project) {
    return (
      <>
        <Header />
        <main className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Projet non trouvé</h1>
            <Link href="/projects">
              <Button>Retour aux projets</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Header />
      <main>
        {/* Breadcrumb */}
        <section className="bg-background border-b">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <Link href="/projects" className="flex items-center text-accent hover:text-accent/80 transition-colors">
              <ChevronLeft className="h-4 w-4 mr-2" />
              Retour aux projets
            </Link>
          </div>
        </section>

        {/* Hero Section */}
        <section className="relative h-64 sm:h-96 md:h-[500px] w-full overflow-hidden">
          <Image src={project.image || "/placeholder.svg"} alt={project.title} fill className="object-cover" priority />
          <div className="absolute inset-0 bg-black/40" />
          <div className="absolute inset-0 flex items-end">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 pb-8">
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white text-balance">{project.title}</h1>
            </div>
          </div>
        </section>

        {/* Project Info Grid */}
        <section className="py-8 md:py-12 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start space-x-4">
                    <Calendar className="h-5 w-5 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">Période</p>
                      <p className="font-semibold">{project.date}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start space-x-4">
                    <MapPin className="h-5 w-5 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">Localisation</p>
                      <p className="font-semibold">{project.location}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start space-x-4">
                    <Users className="h-5 w-5 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">Équipe</p>
                      <p className="font-semibold">{project.team}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start space-x-4">
                    <CheckCircle className="h-5 w-5 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">Statut</p>
                      <p className="font-semibold">{project.status}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Description Section */}
        <section className="py-8 md:py-12 bg-muted/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">À propos du projet</h2>
              <p className="text-base md:text-lg text-muted-foreground mb-6 leading-relaxed">{project.description}</p>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-lg mb-4">Client</h3>
                  <p className="text-muted-foreground">{project.client}</p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-4">Budget</h3>
                  <p className="text-muted-foreground">{project.budget}</p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-4">Durée</h3>
                  <p className="text-muted-foreground">{project.duration}</p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-4">Équipe mobilisée</h3>
                  <p className="text-muted-foreground">{project.team}</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Details Section */}
        <section className="py-8 md:py-12 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-8">Détails du projet</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-semibold text-lg mb-4">Travaux réalisés</h3>
                <ul className="space-y-3">
                  {project.details.map((detail, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-4">Caractéristiques clés</h3>
                <div className="grid gap-4">
                  {project.highlights.map((highlight, index) => (
                    <Card key={index}>
                      <CardContent className="pt-4">
                        <p className="text-sm text-muted-foreground mb-1">{highlight.title}</p>
                        <p className="text-2xl font-bold text-accent">{highlight.value}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Gallery Section */}
        <section className="py-8 md:py-12 bg-muted/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-8">Galerie photos</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
              {project.images.map((image, index) => (
                <div key={index} className="relative h-48 sm:h-64 overflow-hidden rounded-lg">
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`${project.title} - Photo ${index + 1}`}
                    fill
                    className="object-cover hover:scale-105 transition-transform"
                  />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl md:text-4xl font-bold mb-4">Vous avez un projet similaire ?</h2>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto text-balance">
              Contactez-nous pour discuter de votre projet. Notre équipe est prête à vous aider.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/quote">
                <Button size="lg" variant="secondary">
                  Demander un devis
                </Button>
              </Link>
              <Link href="/#contact">
                <Button
                  size="lg"
                  variant="outline"
                  className="text-primary-foreground border-primary-foreground hover:bg-primary-foreground/10 bg-transparent"
                >
                  Nous contacter
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Related Projects */}
        <section className="py-12 md:py-16 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-8">Autres projets</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
              {projects
                .filter((p) => p.slug !== slug)
                .slice(0, 3)
                .map((relatedProject) => (
                  <Link key={relatedProject.slug} href={`/projects/${relatedProject.slug}`}>
                    <Card className="overflow-hidden hover:shadow-lg transition-shadow group cursor-pointer h-full">
                      <div className="relative h-48 overflow-hidden">
                        <Image
                          src={relatedProject.image || "/placeholder.svg"}
                          alt={relatedProject.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform"
                        />
                      </div>
                      <CardContent className="pt-4">
                        <p className="text-sm text-accent font-semibold mb-2">{relatedProject.category}</p>
                        <h3 className="font-bold text-base mb-2 line-clamp-2">{relatedProject.title}</h3>
                        <p className="text-sm text-muted-foreground">{relatedProject.location}</p>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
