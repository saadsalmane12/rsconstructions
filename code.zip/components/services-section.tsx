import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Home, Building, Wrench, Hammer, Shield } from "lucide-react"

const services = [
  {
    icon: Home,
    title: "Rénovation d'appartements",
    description: "Transformation complète de votre appartement avec des finitions adaptées au climat marocain.",
    features: [
      "Cuisine et salle de bain",
      "Électricité et plomberie",
      "Isolation thermique",
      "Décoration traditionnelle",
    ],
  },
  {
    icon: Building,
    title: "Rénovation de villas",
    description: "Rénovation complète de villas avec extension et aménagement style marocain.",
    features: ["Extension de maison", "Aménagement riad", "Piscine et terrasse", "Façade traditionnelle"],
  },
  {
    icon: Hammer,
    title: "Construction d'immeubles",
    description: "Construction de bâtiments résidentiels et commerciaux conformes aux normes marocaines.",
    features: ["Étude de faisabilité", "Gros œuvre", "Second œuvre", "Livraison clés en main"],
  },
  {
    icon: Wrench,
    title: "Maintenance et entretien",
    description: "Services de maintenance adaptés au climat et aux spécificités du Maroc.",
    features: ["Maintenance préventive", "Dépannage urgent", "Contrôle qualité", "Garantie décennale"],
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-16 sm:py-20 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-4 text-balance">
            Nos services d'expertise
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            De la rénovation à la construction neuve, nous couvrons tous vos besoins avec un savoir-faire marocain
            reconnu et des matériaux de qualité.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8 sm:mb-12">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 border-border h-full">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto w-14 h-14 sm:w-16 sm:h-16 bg-accent/10 rounded-full flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <service.icon className="h-7 w-7 sm:h-8 sm:w-8 text-accent" />
                </div>
                <CardTitle className="text-base sm:text-lg text-card-foreground">{service.title}</CardTitle>
                <CardDescription className="text-muted-foreground text-sm">{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start text-sm text-muted-foreground">
                      <Shield className="h-4 w-4 text-accent mr-2 flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent">
            Découvrir tous nos services
          </Button>
        </div>
      </div>
    </section>
  )
}
