import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, Users, Award, Clock } from "lucide-react"

const values = [
  {
    icon: Award,
    title: "Excellence",
    description: "Nous visons l'excellence dans chaque projet avec des matériaux de qualité supérieure.",
  },
  {
    icon: Users,
    title: "Équipe experte",
    description: "Une équipe de professionnels qualifiés et passionnés par leur métier.",
  },
  {
    icon: Clock,
    title: "Respect des délais",
    description: "Nous nous engageons à respecter les délais convenus pour chaque projet.",
  },
  {
    icon: CheckCircle,
    title: "Satisfaction client",
    description: "Votre satisfaction est notre priorité absolue, garantie par notre suivi personnalisé.",
  },
]

export function AboutSection() {
  return (
    <section id="apropos" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground text-balance">
                15 ans d'expertise au service de vos projets
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed text-pretty">
                Fondée en 2009, RS Constructions s'est imposée comme une référence dans le domaine de la construction et
                de la rénovation en Île-de-France. Notre expertise couvre tous les aspects de vos projets, de la
                conception à la livraison.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-foreground">Nos engagements</h3>
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
                  <span className="text-muted-foreground">Devis détaillé et transparent</span>
                </li>
                <li className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
                  <span className="text-muted-foreground">Suivi personnalisé de votre projet</span>
                </li>
                <li className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
                  <span className="text-muted-foreground">Garantie décennale et assurances</span>
                </li>
                <li className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
                  <span className="text-muted-foreground">Respect de l'environnement</span>
                </li>
              </ul>
            </div>

            <Button size="lg">En savoir plus sur notre histoire</Button>
          </div>

          <div className="space-y-6">
            <div className="aspect-[4/3] bg-muted rounded-2xl overflow-hidden">
              <img
                src="/construction-team-site.png"
                alt="Équipe RS Constructions"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              {values.map((value, index) => (
                <Card key={index} className="border-border">
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-3">
                      <value.icon className="h-6 w-6 text-accent" />
                    </div>
                    <h4 className="font-semibold text-card-foreground mb-2">{value.title}</h4>
                    <p className="text-sm text-muted-foreground text-pretty">{value.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
