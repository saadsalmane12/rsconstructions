"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, Phone, X } from "lucide-react"
import { useState } from "react"

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <header className="bg-background border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-2 sm:space-x-3">
            <Image
              src="/images/rs-logo.png"
              alt="RS Constructions"
              width={50}
              height={50}
              className="h-10 sm:h-12 w-auto"
            />
            <div className="hidden sm:block">
              <h1 className="text-lg sm:text-xl font-bold text-foreground">RS Constructions</h1>
              <p className="text-xs sm:text-sm text-muted-foreground">Excellence au Maroc</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6 xl:space-x-8">
            <Link href="/" className="text-foreground hover:text-accent transition-colors text-sm xl:text-base">
              Accueil
            </Link>
            <Link href="/services" className="text-foreground hover:text-accent transition-colors text-sm xl:text-base">
              Services
            </Link>
            <Link href="/projects" className="text-foreground hover:text-accent transition-colors text-sm xl:text-base">
              Projets
            </Link>
            <Link href="/about" className="text-foreground hover:text-accent transition-colors text-sm xl:text-base">
              À propos
            </Link>
            <Link href="/#contact" className="text-foreground hover:text-accent transition-colors text-sm xl:text-base">
              Contact
            </Link>
          </nav>

          <div className="hidden lg:flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Phone className="h-4 w-4" />
              <span>+212 5 22 XX XX XX</span>
            </div>
            <Link href="/quote">
              <Button variant="default" size="sm">
                Devis gratuit
              </Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-border bg-background">
            <nav className="py-4 space-y-2">
              <Link
                href="/"
                className="block px-4 py-2 text-foreground hover:text-accent hover:bg-muted/50 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Accueil
              </Link>
              <Link
                href="/services"
                className="block px-4 py-2 text-foreground hover:text-accent hover:bg-muted/50 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Services
              </Link>
              <Link
                href="/projects"
                className="block px-4 py-2 text-foreground hover:text-accent hover:bg-muted/50 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Projets
              </Link>
              <Link
                href="/about"
                className="block px-4 py-2 text-foreground hover:text-accent hover:bg-muted/50 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                À propos
              </Link>
              <Link
                href="/#contact"
                className="block px-4 py-2 text-foreground hover:text-accent hover:bg-muted/50 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contact
              </Link>
              <div className="px-4 py-2 border-t border-border mt-2 pt-4">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-3">
                  <Phone className="h-4 w-4" />
                  <span>+212 5 22 XX XX XX</span>
                </div>
                <Link href="/quote" className="block">
                  <Button variant="default" size="sm" className="w-full">
                    Devis gratuit
                  </Button>
                </Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
