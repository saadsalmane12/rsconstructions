import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, MapPin } from "lucide-react"
import Link from "next/link"

const projects = [
  {
    slug: "villa-riad-casablanca",
    title: "Rénovation Villa Riad",
    location: "Casablanca",
    date: "2024",
    category: "Rénovation",
    image: "/luxury-villa-renovation-casablanca.jpg",
    description: "Rénovation complète d'une villa traditionnelle avec architecture moderne.",
  },
  {
    slug: "appartement-derb-ghalef-fes",
    title: "Appartement Derb Ghalef",
    location: "Fès",
    date: "2024",
    category: "Rénovation",
    image: "/apartment-renovation-fes.jpg",
    description: "Rénovation d'un appartement de 120m² alliant charme ancien et confort moderne.",
  },
  {
    slug: "immeuble-residenciel-marrakech",
    title: "Résidence Moderne",
    location: "Marrakech",
    date: "2023",
    category: "Construction",
    image: "/modern-residential-building-marrakech.jpg",
    description: "Construction d'une résidence de 45 logements avec espaces verts.",
  },
  {
    slug: "villa-moderne-piscine-rabat",
    title: "Villa avec Piscine",
    location: "Rabat",
    date: "2023",
    category: "Rénovation",
    image: "/modern-villa-with-pool-rabat.jpg",
    description: "Villa moderne de 200m² avec piscine, terrasse et jardin paysager.",
  },
]

export function ProjectsSection() {
  return (
    <section id="projets" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4 text-balance">
            Nos réalisations récentes
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Découvrez quelques-uns de nos projets les plus emblématiques, témoins de notre expertise et de notre
            engagement qualité.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {projects.map((project) => (
            <Card
              key={project.slug}
              className="group overflow-hidden border-border hover:shadow-lg transition-all duration-300"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <Badge variant="secondary" className="text-xs">
                    {project.category}
                  </Badge>
                  <span className="text-xs text-muted-foreground">{project.date}</span>
                </div>

                <h3 className="font-semibold text-card-foreground mb-2 text-balance">{project.title}</h3>

                <div className="flex items-center text-sm text-muted-foreground mb-3">
                  <MapPin className="h-4 w-4 mr-1" />
                  {project.location}
                </div>

                <p className="text-sm text-muted-foreground mb-4 text-pretty">{project.description}</p>

                <Link href={`/projects/${project.slug}`}>
                  <Button variant="ghost" size="sm" className="p-0 h-auto text-accent hover:text-accent/80">
                    Voir le projet
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link href="/projects">
            <Button size="lg">
              Voir tous nos projets
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
