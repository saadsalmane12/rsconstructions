import { Button } from "@/components/ui/button"
import { ArrowRight, Award, Users, Calendar } from "lucide-react"

export function HeroSection() {
  return (
    <section id="accueil" className="relative bg-gradient-to-br from-background to-muted py-16 sm:py-20 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          <div className="space-y-6 lg:space-y-8">
            <div className="space-y-4">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-foreground leading-tight text-balance">
                Votre partenaire en <span className="text-accent">construction</span> et{" "}
                <span className="text-accent">rénovation</span> au Maroc
              </h1>
              <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed text-pretty">
                Spécialistes de la rénovation d'appartements et villas, ainsi que de la construction d'immeubles à
                travers le Royaume. Nous transformons vos projets en réalité avec expertise et qualité marocaine.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
              <Button size="lg" className="bg-primary hover:bg-primary/90 w-full sm:w-auto">
                Demander un devis gratuit
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="w-full sm:w-auto bg-transparent">
                Voir nos projets
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 pt-6 sm:pt-8 border-t border-border">
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <Award className="h-6 w-6 sm:h-8 sm:w-8 text-accent" />
                </div>
                <div className="text-xl sm:text-2xl font-bold text-foreground">15+</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Années d'expérience</div>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <Users className="h-6 w-6 sm:h-8 sm:w-8 text-accent" />
                </div>
                <div className="text-xl sm:text-2xl font-bold text-foreground">500+</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Projets au Maroc</div>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <Calendar className="h-6 w-6 sm:h-8 sm:w-8 text-accent" />
                </div>
                <div className="text-xl sm:text-2xl font-bold text-foreground">100%</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Satisfaction client</div>
              </div>
            </div>
          </div>

          <div className="relative mt-8 lg:mt-0">
            <div className="aspect-[4/3] sm:aspect-square bg-muted rounded-2xl overflow-hidden">
              <img
                src="/modern-construction-site-in-morocco-with-tradition.jpg"
                alt="Chantier de construction moderne au Maroc"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -left-4 sm:-bottom-6 sm:-left-6 bg-card border border-border rounded-xl p-4 sm:p-6 shadow-lg max-w-[200px] sm:max-w-none">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-accent rounded-full flex items-center justify-center">
                  <Award className="h-5 w-5 sm:h-6 sm:w-6 text-accent-foreground" />
                </div>
                <div>
                  <div className="font-semibold text-card-foreground text-sm sm:text-base">Certifié ONEE</div>
                  <div className="text-xs sm:text-sm text-muted-foreground">Qualité garantie</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
