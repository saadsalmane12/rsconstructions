import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Phone, Mail, MapPin, Clock } from "lucide-react"

export function ContactSection() {
  return (
    <section id="contact" className="py-16 sm:py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-4 text-balance">
            Contactez-nous pour votre projet
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Prêt à concrétiser votre projet au Maroc ? Contactez-nous pour un devis gratuit et personnalisé. Notre
            équipe vous accompagne à chaque étape.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 lg:gap-8">
          <div className="lg:col-span-2">
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground text-lg sm:text-xl">Demande de devis gratuit</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 sm:space-y-6">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-card-foreground">Prénom *</label>
                    <Input placeholder="Votre prénom" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-card-foreground">Nom *</label>
                    <Input placeholder="Votre nom" />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-card-foreground">Email *</label>
                    <Input type="email" placeholder="votre@email.com" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-card-foreground">Téléphone</label>
                    <Input placeholder="+212 6 XX XX XX XX" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-card-foreground">Ville *</label>
                  <select className="w-full p-3 border border-border rounded-md bg-background text-foreground">
                    <option>Sélectionnez votre ville</option>
                    <option>Casablanca</option>
                    <option>Rabat</option>
                    <option>Marrakech</option>
                    <option>Fès</option>
                    <option>Tanger</option>
                    <option>Agadir</option>
                    <option>Meknès</option>
                    <option>Oujda</option>
                    <option>Autre</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-card-foreground">Type de projet *</label>
                  <select className="w-full p-3 border border-border rounded-md bg-background text-foreground">
                    <option>Sélectionnez votre projet</option>
                    <option>Rénovation d'appartement</option>
                    <option>Rénovation de villa</option>
                    <option>Construction d'immeuble</option>
                    <option>Construction de villa</option>
                    <option>Maintenance et entretien</option>
                    <option>Autre</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-card-foreground">Description du projet *</label>
                  <Textarea
                    placeholder="Décrivez votre projet en détail : surface, localisation, délais souhaités, budget approximatif..."
                    rows={4}
                  />
                </div>

                <Button size="lg" className="w-full">
                  Envoyer ma demande
                </Button>

                <p className="text-sm text-muted-foreground text-center">
                  * Champs obligatoires. Vos données sont protégées et ne seront jamais partagées.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4 sm:space-y-6">
            <Card className="border-border">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-accent/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="h-5 w-5 sm:h-6 sm:w-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-card-foreground mb-1 text-sm sm:text-base">Téléphone</h3>
                    <p className="text-muted-foreground text-sm sm:text-base">+212 5 22 XX XX XX</p>
                    <p className="text-xs sm:text-sm text-muted-foreground">Lun-Ven 8h-18h</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-accent/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Mail className="h-5 w-5 sm:h-6 sm:w-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-card-foreground mb-1 text-sm sm:text-base">Email</h3>
                    <p className="text-muted-foreground text-sm sm:text-base">contact@rs-constructions.ma</p>
                    <p className="text-xs sm:text-sm text-muted-foreground">Réponse sous 24h</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-accent/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-5 w-5 sm:h-6 sm:w-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-card-foreground mb-1 text-sm sm:text-base">Adresse</h3>
                    <p className="text-muted-foreground text-sm sm:text-base">
                      123 Boulevard Mohammed V
                      <br />
                      Casablanca 20000, Maroc
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-accent/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="h-5 w-5 sm:h-6 sm:w-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-card-foreground mb-1 text-sm sm:text-base">Horaires</h3>
                    <p className="text-muted-foreground text-sm sm:text-base">
                      Lun-Ven : 8h00 - 18h00
                      <br />
                      Sam : 9h00 - 12h00
                      <br />
                      Dim : Fermé
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
